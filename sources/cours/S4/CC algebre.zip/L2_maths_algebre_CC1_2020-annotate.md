---
annotate-target: sources/cours/S4/L2_maths_algebre_CC1_2020.pdf
---

>%%
>```annotate-json
>{"id":"5684c339-8100-575e","text":"{\"id\":\"5684c339-8100-575e\",\"page\":0,\"rect\":[49.16733923303835,693.5099941002951],\"contents\":\"\",\"author\":\"\",\"color\":{\"r\":249,\"g\":233,\"b\":204},\"opacity\":1,\"path\":\"attachments/markmind/1677687561872.png\",\"relateRect\":[{\"x\":0.08112094395280237,\"y\":0.24778761061946902,\"width\":0.834070796460177,\"height\":0.19469026548672566}],\"pdfName\":\"sources/cours/S4/L2_maths_algebre_CC1_2020.pdf\",\"pageWidth\":1356,\"imageAbsolutePath\":\"app://local/Users/oscarplaisant/devoirs/cours/attachments/markmind/1677687561872.png?1677687561931\"}","type":"rect","page":0,"width":1131,"height":264,"pdfName":"sources/cours/S4/L2_maths_algebre_CC1_2020.pdf"}
>```
>%%
>![[attachments/markmind/1677687561872.png]]
>[[#^5684c339-8100-575e|Show annotate]]
>
^5684c339-8100-575e

>%%
>```annotate-json
>{"id":"2fd5e1d1-e6fb-3c44","text":"{\"id\":\"2fd5e1d1-e6fb-3c44\",\"page\":0,\"rect\":[49.16733923303835,693.5099941002951,43.460415929203535,564.4457286135694],\"contents\":\"\",\"author\":\"\",\"color\":{\"r\":249,\"g\":233,\"b\":204},\"opacity\":1,\"path\":\"attachments/markmind/1677687571573.png\",\"relateRect\":[{\"x\":0.0715339233038348,\"y\":0.4646017699115044,\"width\":0.8333333333333334,\"height\":0.20058997050147492}],\"pdfName\":\"sources/cours/S4/L2_maths_algebre_CC1_2020.pdf\",\"pageWidth\":1356,\"imageAbsolutePath\":\"app://local/Users/oscarplaisant/devoirs/cours/attachments/markmind/1677687571573.png?1677687571596\"}","type":"rect","page":0,"width":1130,"height":272,"pdfName":"sources/cours/S4/L2_maths_algebre_CC1_2020.pdf"}
>```
>%%
>![[attachments/markmind/1677687571573.png]]
>[[#^2fd5e1d1-e6fb-3c44|Show annotate]]
>
^2fd5e1d1-e6fb-3c44

>%%
>```annotate-json
>{"id":"9684bb19-c877-d648","text":"{\"id\":\"9684bb19-c877-d648\",\"page\":0,\"rect\":[49.16733923303835,693.5099941002951,43.460415929203535,564.4457286135694,46.09438053097345,431.8695103244839],\"contents\":\"\",\"author\":\"\",\"color\":{\"r\":249,\"g\":233,\"b\":204},\"opacity\":1,\"path\":\"attachments/markmind/1677687594503.png\",\"relateRect\":[{\"x\":0.07595870206489676,\"y\":0.6873156342182891,\"width\":0.6592920353982301,\"height\":0.18584070796460178}],\"pdfName\":\"sources/cours/S4/L2_maths_algebre_CC1_2020.pdf\",\"pageWidth\":1356,\"imageAbsolutePath\":\"app://local/Users/oscarplaisant/devoirs/cours/attachments/markmind/1677687594503.png?1677687594528\"}","type":"rect","page":0,"width":894,"height":252,"pdfName":"sources/cours/S4/L2_maths_algebre_CC1_2020.pdf"}
>```
>%%
>![[attachments/markmind/1677687594503.png]]
>[[#^9684bb19-c877-d648|Show annotate]]
>
^9684bb19-c877-d648

