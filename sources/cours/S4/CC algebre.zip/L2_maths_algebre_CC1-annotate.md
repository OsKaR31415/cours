---
annotate-target: sources/cours/S4/L2_maths_algebre_CC1.pdf
---

>%%
>```annotate-json
>{"id":"5b30c544-da4a-995c","text":"{\"id\":\"5b30c544-da4a-995c\",\"page\":0,\"rect\":[49.606333333333325,589.9073864306786],\"contents\":\"\",\"author\":\"\",\"color\":{\"r\":249,\"g\":233,\"b\":204},\"opacity\":1,\"path\":\"attachments/markmind/1677696331742.png\",\"relateRect\":[{\"x\":0.08185840707964602,\"y\":0.4218289085545723,\"width\":0.8488200589970502,\"height\":0.016224188790560472}],\"pdfName\":\"sources/cours/S4/L2_maths_algebre_CC1.pdf\",\"pageWidth\":1356,\"imageAbsolutePath\":\"app://local/Users/oscarplaisant/devoirs/cours/attachments/markmind/1677696331742.png?1677696331786\"}","type":"rect","page":0,"width":1151,"height":22,"pdfName":"sources/cours/S4/L2_maths_algebre_CC1.pdf"}
>```
>%%
>![[attachments/markmind/1677696331742.png]]
>[[#^5b30c544-da4a-995c|Show annotate]]
>
^5b30c544-da4a-995c

>%%
>```annotate-json
>{"id":"aa7b8039-4202-b975","text":"{\"id\":\"aa7b8039-4202-b975\",\"page\":0,\"rect\":[49.606333333333325,589.9073864306786,48.28935103244837,398.06696460177],\"contents\":\"\",\"author\":\"\",\"color\":{\"r\":249,\"g\":233,\"b\":204},\"opacity\":1,\"path\":\"attachments/markmind/1677702410025.png\",\"relateRect\":[{\"x\":0.07964601769911504,\"y\":0.7441002949852508,\"width\":0.8333333333333334,\"height\":0.2529498525073746}],\"pdfName\":\"sources/cours/S4/L2_maths_algebre_CC1.pdf\",\"pageWidth\":1356,\"imageAbsolutePath\":\"app://local/Users/oscarplaisant/devoirs/cours/attachments/markmind/1677702410025.png?1677702410072\"}","type":"rect","page":0,"width":1130,"height":343,"pdfName":"sources/cours/S4/L2_maths_algebre_CC1.pdf"}
>```
>%%
>![[attachments/markmind/1677702410025.png]]
>[[#^aa7b8039-4202-b975|Show annotate]]
>
^aa7b8039-4202-b975

>%%
>```annotate-json
>{"id":"283004ba-3356-ad40","text":"{\"id\":\"283004ba-3356-ad40\",\"page\":0,\"rect\":[49.606333333333325,589.9073864306786,48.28935103244837,398.06696460177,50.045327433628316,233.44417699115053],\"contents\":\"\",\"author\":\"\",\"color\":{\"r\":249,\"g\":233,\"b\":204},\"opacity\":1,\"path\":\"attachments/markmind/1677702414155.png\",\"relateRect\":[{\"x\":0.08259587020648967,\"y\":1.0206489675516224,\"width\":0.8702064896755162,\"height\":0.3075221238938053}],\"pdfName\":\"sources/cours/S4/L2_maths_algebre_CC1.pdf\",\"pageWidth\":1356,\"imageAbsolutePath\":\"app://local/Users/oscarplaisant/devoirs/cours/attachments/markmind/1677702414155.png?1677702414176\"}","type":"rect","page":0,"width":1180,"height":417,"pdfName":"sources/cours/S4/L2_maths_algebre_CC1.pdf"}
>```
>%%
>![[attachments/markmind/1677702414155.png]]
>[[#^283004ba-3356-ad40|Show annotate]]
>
^283004ba-3356-ad40

